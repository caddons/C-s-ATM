ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.PrintName		= "C's Blue ATM"
ENT.Category		= "C's Addons"
ENT.Author			= "Coulter"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.Spawnable	= true